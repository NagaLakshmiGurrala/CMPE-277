package com.example.implicitintents;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    EditText urlInput, phoneInput;
    Button launchButton, ringButton, closeButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main); // Link to the XML layout

        urlInput = findViewById(R.id.urlInput);
        phoneInput = findViewById(R.id.phoneInput);
        launchButton = findViewById(R.id.launchButton);
        ringButton = findViewById(R.id.ringButton);
        closeButton = findViewById(R.id.closeButton);

        // Open URL in a web browser
        launchButton.setOnClickListener(view -> {
            String url = urlInput.getText().toString().trim();
            if (!url.isEmpty()) {
                if (!url.startsWith("http://") && !url.startsWith("https://")) {
                    url = "http://" + url;
                }
                Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
                startActivity(intent);
            } else {
                Toast.makeText(MainActivity.this, getString(R.string.error_url), Toast.LENGTH_SHORT).show();
            }
        });

        // Open phone dialer
        ringButton.setOnClickListener(view -> {
            String phone = phoneInput.getText().toString().trim();
            if (!phone.isEmpty()) {
                Intent intent = new Intent(Intent.ACTION_DIAL, Uri.parse("tel:" + phone));
                startActivity(intent);
            } else {
                Toast.makeText(MainActivity.this, getString(R.string.error_phone), Toast.LENGTH_SHORT).show();
            }
        });

        // Close App
        closeButton.setOnClickListener(view -> finish());
    }
}

