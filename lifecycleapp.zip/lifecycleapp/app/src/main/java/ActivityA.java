package com.example.lifecycleapp;

import android.app.Dialog;
import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;

public class ActivityA extends AppCompatActivity {

    private int counter = 0;
    private int restartCounter = 0; // Counts the number of times onRestart() is triggered
    private TextView threadCounterTextView, restartCounterTextView;

    private final ActivityResultLauncher<Intent> activityBLauncher =
            registerForActivityResult(new ActivityResultContracts.StartActivityForResult(),
                    result -> {
                        if (result.getResultCode() == RESULT_OK && result.getData() != null) {
                            int increment = result.getData().getIntExtra("counterIncrement", 0);
                            counter += increment;
                            updateCounter();
                        }
                    });

    private final ActivityResultLauncher<Intent> activityCLauncher =
            registerForActivityResult(new ActivityResultContracts.StartActivityForResult(),
                    result -> {
                        if (result.getResultCode() == RESULT_OK && result.getData() != null) {
                            int increment = result.getData().getIntExtra("counterIncrement", 0);
                            counter += increment;
                            updateCounter();
                        }
                    });

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_a);

        Button startActivityB = findViewById(R.id.buttonActivityB);
        Button startActivityC = findViewById(R.id.buttonActivityC);
        Button showDialog = findViewById(R.id.buttonDialog);
        Button closeApp = findViewById(R.id.buttonCloseApp);
        threadCounterTextView = findViewById(R.id.textThreadCounter);
        restartCounterTextView = findViewById(R.id.textRestartCounter); // Add a new TextView for onRestart counter

        startActivityB.setOnClickListener(v -> {
            Intent intent = new Intent(ActivityA.this, ActivityB.class);
            activityBLauncher.launch(intent);
        });

        startActivityC.setOnClickListener(v -> {
            Intent intent = new Intent(ActivityA.this, ActivityC.class);
            activityCLauncher.launch(intent);
        });

        showDialog.setOnClickListener(v -> showCustomDialog());

        closeApp.setOnClickListener(v -> finish());

        updateCounter();
    }

    private void showCustomDialog() {
        Dialog dialog = new Dialog(this);
        dialog.setContentView(R.layout.dialog_layout);
        Button closeDialog = dialog.findViewById(R.id.buttonCloseDialog);
        closeDialog.setOnClickListener(v -> dialog.dismiss());
        dialog.show();
    }

    private void updateCounter() {
        threadCounterTextView.setText("Thread Counter: " + String.format("%04d", counter));
        restartCounterTextView.setText("onRestart Counter: " + restartCounter);
    }

    @Override
    protected void onRestart() {
        super.onRestart();
        restartCounter++; // Increment the restart counter
        updateCounter();
    }
}



