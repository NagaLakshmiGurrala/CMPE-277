package com.example.lifecycleapp;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

public class ActivityB extends AppCompatActivity {

    private int counterIncrement = 5;
    private int restartCounter = 0; // Counter for onRestart calls
    private TextView restartCounterTextView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_b);

        restartCounterTextView = findViewById(R.id.textRestartCounter); // Display onRestart counter

        Button finishButton = findViewById(R.id.buttonFinishB);
        finishButton.setOnClickListener(v -> {
            Intent resultIntent = new Intent();
            resultIntent.putExtra("counterIncrement", counterIncrement);
            setResult(RESULT_OK, resultIntent);
            finish();
        });

        updateCounter();
    }

    private void updateCounter() {
        restartCounterTextView.setText("onRestart Counter: " + restartCounter);
    }

    @Override
    protected void onRestart() {
        super.onRestart();
        restartCounter++;
        updateCounter();
    }
}



