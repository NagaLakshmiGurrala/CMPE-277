package com.example.pdfdownloader;

import android.app.IntentService;
import android.content.Intent;
import android.os.Environment;
import android.util.Log;

import androidx.annotation.Nullable;

import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;

public class DownloadService extends IntentService {

    public DownloadService() {
        super("DownloadService");
    }

    @Override
    protected void onHandleIntent(@Nullable Intent intent) {
        if (intent != null && intent.hasExtra("url")) {
            String fileUrl = intent.getStringExtra("url");
            downloadFile(fileUrl);
        }
    }

    private void downloadFile(String fileUrl) {
        try {
            URL url = new URL(fileUrl);
            HttpURLConnection connection = (HttpURLConnection) url.openConnection();
            connection.connect();

            InputStream input = new BufferedInputStream(url.openStream());

            File downloadsDir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS);
            if (!downloadsDir.exists()) {
                downloadsDir.mkdirs();
            }

            String fileName = fileUrl.substring(fileUrl.lastIndexOf('/') + 1);
            File outputFile = new File(downloadsDir, fileName);

            FileOutputStream output = new FileOutputStream(outputFile);
            byte[] buffer = new byte[1024];
            int count;

            while ((count = input.read(buffer)) > 0) {
                output.write(buffer, 0, count);
            }

            output.flush();
            output.close();
            input.close();

            Log.d("DownloadService", "File downloaded: " + outputFile.getAbsolutePath());

        } catch (Exception e) {
            e.printStackTrace();
            Log.e("DownloadService", "Download error: " + e.getMessage());
        }
    }
}

