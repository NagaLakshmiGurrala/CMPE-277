package com.example.pdfdownloader;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    EditText edit1, edit2, edit3, edit4, edit5;
    Button downloadBtn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        edit1 = findViewById(R.id.editText1);
        edit2 = findViewById(R.id.editText2);
        edit3 = findViewById(R.id.editText3);
        edit4 = findViewById(R.id.editText4);
        edit5 = findViewById(R.id.editText5);
        downloadBtn = findViewById(R.id.downloadButton);

        downloadBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startDownload(edit1.getText().toString());
                startDownload(edit2.getText().toString());
                startDownload(edit3.getText().toString());
                startDownload(edit4.getText().toString());
                startDownload(edit5.getText().toString());

                Toast.makeText(MainActivity.this, "Downloading started!", Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void startDownload(String url) {
        if (url != null && !url.trim().isEmpty()) {
            Intent intent = new Intent(this, DownloadService.class);
            intent.putExtra("url", url.trim());
            startService(intent);
        }
    }
}


